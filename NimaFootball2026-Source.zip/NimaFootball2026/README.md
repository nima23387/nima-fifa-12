# Nima Football 2026 — Android source

A lightweight, landscape, Android 2.3.7-compatible football game prototype.

## Included in this first playable build
- Top-down broadcast-style camera that follows the ball
- Virtual left joystick
- PASS, SHOOT, SPRINT and SWITCH buttons
- Moving player, simple teammates/opponents and ball physics
- English-only game interface
- Quick Match and career-mode entry screens (career systems are currently scaffolding, not complete seasons)

## Important
This is an original lightweight football game foundation, not FIFA 12 and not a finished commercial-scale football game. It does not include licensed FIFA assets, official club crests, real player likenesses, full leagues, transfers or complete career simulation yet. Those require separate data and development.

## Build
The GitHub Actions workflow in `.github/workflows/build.yml` builds a debug APK and uploads it as an artifact.
For a local legacy Android Ant build, install Android SDK platform API 10 and Ant, then run:
`android update project --path . --target android-10`
`ant debug`

Package: `com.nima.football`
Minimum Android: 2.3 (API 10)
