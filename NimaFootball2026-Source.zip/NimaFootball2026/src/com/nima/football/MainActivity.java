package com.nima.football;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.MotionEvent;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Color;
import android.graphics.RectF;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import java.util.Random;

public class MainActivity extends Activity {
    public void onCreate(Bundle b) {
        super.onCreate(b);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(new FootballView());
    }

    class FootballView extends SurfaceView implements SurfaceHolder.Callback, Runnable {
        private Thread thread;
        private volatile boolean running = false;
        private SurfaceHolder holder;
        private Paint p = new Paint();
        private int screen = 0; // 0 menu, 1 match, 2 career
        private int careerType = 0;
        private int scoreHome = 0, scoreAway = 0, seconds = 0;
        private long lastClock = 0;
        private float w = 480, h = 320;
        private float worldW = 1200, worldH = 760;
        private float camX = 0, camY = 0;
        private float ballX = 600, ballY = 380, ballVX = 0, ballVY = 0;
        private float userX = 520, userY = 380, userVX = 0, userVY = 0;
        private float joyX = 0, joyY = 0;
        private boolean joyActive = false, sprint = false;
        private boolean passPressed = false, shootPressed = false, switchPressed = false;
        private int selected = 0;
        private float[] teammateX = {430, 360, 520, 600, 700};
        private float[] teammateY = {300, 460, 250, 510, 380};
        private float[] enemyX = {780, 850, 930, 740, 1020, 900};
        private float[] enemyY = {280, 480, 200, 570, 380, 650};
        private Random random = new Random();

        FootballView() {
            super(MainActivity.this);
            holder = getHolder();
            holder.addCallback(this);
            p.setAntiAlias(true);
            setFocusable(true);
        }

        public void surfaceCreated(SurfaceHolder hld) {
            running = true;
            thread = new Thread(this);
            thread.start();
        }
        public void surfaceChanged(SurfaceHolder hld, int f, int wi, int he) {}
        public void surfaceDestroyed(SurfaceHolder hld) {
            running = false;
            boolean retry = true;
            while (retry) {
                try { if (thread != null) thread.join(); retry = false; }
                catch (InterruptedException e) {}
            }
        }

        public void run() {
            while (running) {
                if (!holder.getSurface().isValid()) continue;
                Canvas c = holder.lockCanvas();
                if (c != null) {
                    w = c.getWidth(); h = c.getHeight();
                    if (screen == 1) updateGame();
                    drawScene(c);
                    holder.unlockCanvasAndPost(c);
                }
                try { Thread.sleep(33); } catch (InterruptedException e) {}
            }
        }

        private void updateGame() {
            float speed = sprint ? 4.0f : 2.7f;
            userVX = joyX * speed;
            userVY = joyY * speed;
            userX += userVX; userY += userVY;
            clampPlayers();
            float dx = ballX - userX, dy = ballY - userY;
            if (dx * dx + dy * dy < 1050) {
                if (passPressed) {
                    ballVX = 5.8f + userVX * 0.5f;
                    ballVY = userVY * 0.8f + (random.nextFloat() - 0.5f) * 1.2f;
                    passPressed = false;
                } else if (shootPressed) {
                    ballVX = 10.5f + userVX * 0.4f;
                    ballVY = (ballY - userY) * 0.04f + userVY * 0.7f;
                    shootPressed = false;
                }
            }
            ballX += ballVX; ballY += ballVY;
            ballVX *= 0.985f; ballVY *= 0.985f;
            if (ballY < 85 || ballY > worldH - 85) ballVY = -ballVY;
            // Goals are placed at both ends of the pitch.
            if (ballX <= 24 && ballY > 300 && ballY < 460) {
                scoreAway++;
                resetBall();
            } else if (ballX >= worldW - 24 && ballY > 300 && ballY < 460) {
                scoreHome++;
                resetBall();
            } else {
                if (ballX < 35) { ballX = 35; ballVX = Math.abs(ballVX); }
                if (ballX > worldW - 35) {
                    ballX = worldW - 35; ballVX = -Math.abs(ballVX);
                }
            }
            // Basic opposing players chase the ball.
            for (int i = 0; i < enemyX.length; i++) {
                float ex = ballX - enemyX[i], ey = ballY - enemyY[i];
                float len = (float)Math.sqrt(ex*ex + ey*ey);
                if (len > 1) { enemyX[i] += ex / len * 0.65f; enemyY[i] += ey / len * 0.65f; }
            }
            if (switchPressed) {
                selected = (selected + 1) % teammateX.length;
                userX = teammateX[selected]; userY = teammateY[selected];
                switchPressed = false;
            }
            // Camera follows the ball with a soft, broadcast-like offset.
            float targetX = ballX - w * 0.50f;
            float targetY = ballY - h * 0.50f;
            camX += (targetX - camX) * 0.08f;
            camY += (targetY - camY) * 0.08f;
            if (camX < 0) camX = 0;
            if (camY < 0) camY = 0;
            if (camX > worldW - w) camX = worldW - w;
            if (camY > worldH - h) camY = worldH - h;
            long now = System.currentTimeMillis();
            if (lastClock == 0) lastClock = now;
            if (now - lastClock > 1000) { seconds++; lastClock = now; }
            if (seconds >= 90) { screen = 0; seconds = 0; lastClock = 0; }
        }


        private void resetBall() {
            ballX = worldW / 2;
            ballY = worldH / 2;
            ballVX = 0;
            ballVY = 0;
            userX = worldW / 2 - 70;
            userY = worldH / 2;
        }

        private void clampPlayers() {
            if (userX < 30) userX = 30;
            if (userX > worldW-30) userX = worldW-30;
            if (userY < 90) userY = 90;
            if (userY > worldH-90) userY = worldH-90;
        }

        private void drawScene(Canvas c) {
            c.drawColor(Color.rgb(10, 18, 28));
            if (screen == 0) drawMenu(c);
            else if (screen == 1) drawMatch(c);
            else drawCareer(c);
        }

        private void text(Canvas c, String s, float x, float y, float size, int color) {
            p.setColor(color); p.setTextSize(size); p.setFakeBoldText(true);
            c.drawText(s, x, y, p); p.setFakeBoldText(false);
        }
        private void rounded(Canvas c, float l, float t, float r, float b, int color) {
            p.setColor(color); c.drawRoundRect(new RectF(l,t,r,b), 10,10,p);
        }

        private void drawMenu(Canvas c) {
            text(c, "NIMA FOOTBALL 2026", w*0.18f, h*0.19f, Math.max(22,w*0.055f), Color.WHITE);
            text(c, "MEN'S & WOMEN'S FOOTBALL", w*0.25f, h*0.27f, 13, Color.rgb(90,220,210));
            menuButton(c, "QUICK MATCH", 0, h*0.37f);
            menuButton(c, "MEN'S MANAGER CAREER", 1, h*0.49f);
            menuButton(c, "WOMEN'S MANAGER CAREER", 2, h*0.61f);
            menuButton(c, "PLAYER CAREER", 3, h*0.73f);
            text(c, "X8 EDITION  |  ANDROID 2.3.7", 12, h-12, 10, Color.LTGRAY);
        }
        private void menuButton(Canvas c, String s, int id, float y) {
            float left = w*0.22f, right = w*0.78f;
            rounded(c,left,y,right,y+31,Color.rgb(20,75,85));
            text(c,s,left+12,y+21,13,Color.WHITE);
        }
        private void drawCareer(Canvas c) {
            text(c, careerType == 1 ? "MEN'S MANAGER CAREER" :
                    careerType == 2 ? "WOMEN'S MANAGER CAREER" : "PLAYER CAREER",
                    20, 45, 21, Color.WHITE);
            text(c, "SEASON 2026/27", 20, 82, 15, Color.rgb(80,220,200));
            text(c, "TEAM: NIMA UNITED", 20, 118, 14, Color.WHITE);
            text(c, "LEAGUE POSITION: --", 20, 148, 14, Color.WHITE);
            text(c, "SQUAD / TRAINING / TRANSFERS", 20, 178, 13, Color.LTGRAY);
            rounded(c,20,h-62,150,h-25,Color.rgb(20,75,85));
            text(c,"BACK",55,h-38,15,Color.WHITE);
            text(c,"CAREER MODE FOUNDATION - MORE SYSTEMS TO COME",20,h-78,10,Color.GRAY);
        }

        private void drawMatch(Canvas c) {
            c.save();
            c.scale(w / 480f, h / 320f);
            c.translate(-camX * 480f / w, -camY * 320f / h);
            // Pitch and mowing stripes.
            p.setColor(Color.rgb(34,125,67)); c.drawRect(0,0,worldW,worldH,p);
            for (int i=0;i<12;i++) {
                p.setColor(i%2==0?Color.argb(28,255,255,255):Color.argb(10,0,0,0));
                c.drawRect(i*100,0,(i+1)*100,worldH,p);
            }
            p.setColor(Color.WHITE); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(3);
            c.drawRect(35,85,worldW-35,worldH-85,p);
            c.drawLine(worldW/2,85,worldW/2,worldH-85,p);
            c.drawCircle(worldW/2,worldH/2,90,p);
            c.drawRect(35,260,180,500,p);
            c.drawRect(worldW-180,260,worldW-35,500,p);
            c.drawRect(0,300,35,460,p);
            c.drawRect(worldW-35,300,worldW,460,p);
            p.setStyle(Paint.Style.FILL);
            // Players.
            drawPlayer(c,userX,userY,Color.rgb(40,190,245),13);
            for(int i=0;i<teammateX.length;i++) drawPlayer(c,teammateX[i],teammateY[i],Color.rgb(40,190,245),10);
            for(int i=0;i<enemyX.length;i++) drawPlayer(c,enemyX[i],enemyY[i],Color.rgb(235,65,65),11);
            p.setColor(Color.WHITE); c.drawCircle(ballX,ballY,7,p);
            p.setColor(Color.BLACK); c.drawCircle(ballX+2,ballY+2,2,p);
            c.restore();
            // Score overlay.
            rounded(c,w*0.35f,5,w*0.65f,34,Color.argb(210,5,15,25));
            text(c,"NIMA UTD  "+scoreHome+" - "+scoreAway+"  OPPONENT",w*0.365f,25,10,Color.WHITE);
            text(c,"00:"+String.format("%02d",seconds),w-55,49,11,Color.WHITE);
            drawControls(c);
        }
        private void drawPlayer(Canvas c,float x,float y,int color,float r) {
            p.setColor(Color.argb(80,0,0,0)); c.drawCircle(x+3,y+4,r,p);
            p.setColor(color); c.drawCircle(x,y,r,p);
            p.setColor(Color.WHITE); c.drawCircle(x-3,y-3,2,p);
        }
        private void drawControls(Canvas c) {
            float baseX=68, baseY=h-66;
            p.setColor(Color.argb(75,230,240,245)); c.drawCircle(baseX,baseY,43,p);
            p.setColor(Color.argb(160,255,255,255)); c.drawCircle(baseX+joyX*25,baseY+joyY*25,17,p);
            action(c,"PASS",w-155,h-112,62,40);
            action(c,"SHOOT",w-82,h-70,65,42);
            action(c,"SPRINT",w-158,h-56,62,34);
            action(c,"SWITCH",w-235,h-56,62,34);
        }
        private void action(Canvas c,String s,float x,float y,float ww,float hh) {
            rounded(c,x,y,x+ww,y+hh,Color.argb(175,8,25,38));
            text(c,s,x+8,y+hh/2+5,11,Color.WHITE);
        }

        public boolean onTouchEvent(MotionEvent e) {
            float x=e.getX(), y=e.getY();
            int action=e.getAction();
            if (screen == 0) {
                if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_UP) {
                    if (y > h*0.34f && y < h*0.47f) { startMatch(); }
                    else if (y > h*0.47f && y < h*0.59f) { careerType=1; screen=2; }
                    else if (y > h*0.59f && y < h*0.71f) { careerType=2; screen=2; }
                    else if (y > h*0.71f && y < h*0.84f) { careerType=3; screen=2; }
                }
                return true;
            }
            if (screen == 2) {
                if (action == MotionEvent.ACTION_DOWN && y > h-75) screen=0;
                return true;
            }
            if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_MOVE) {
                if (x < w*0.27f && y > h*0.55f) {
                    joyActive=true;
                    float dx=(x-68)/(43f), dy=(y-(h-66))/(43f);
                    float len=(float)Math.sqrt(dx*dx+dy*dy);
                    if(len>1){dx/=len;dy/=len;}
                    joyX=dx; joyY=dy;
                } else {
                    joyActive=false; joyX=0; joyY=0;
                    if (x > w-170 && y > h-145 && y < h-65) passPressed=true;
                    if (x > w-100 && y > h-90) shootPressed=true;
                    if (x > w-175 && x < w-95 && y > h-65) sprint=true;
                    if (x > w-250 && x < w-175 && y > h-65) switchPressed=true;
                }
            }
            if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
                joyX=0; joyY=0; joyActive=false; sprint=false;
            }
            return true;
        }

        private void startMatch() {
            screen=1; scoreHome=0; scoreAway=0; seconds=0; lastClock=0;
            ballX=600; ballY=380; userX=520; userY=380; ballVX=0; ballVY=0;
            camX=360; camY=220;
        }
    }
}
